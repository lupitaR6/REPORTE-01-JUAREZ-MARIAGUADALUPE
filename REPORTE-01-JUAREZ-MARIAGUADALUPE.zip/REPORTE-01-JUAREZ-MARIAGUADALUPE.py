
#PROYECTO 1 EMTECH

import math

from sympy import multiplicity

"""
This is the LifeStore_SalesList data:

lifestore_searches = [id_search, id product]
lifestore_sales = [id_sale, id_product, score (from 1 to 5), date, refund (1 for true or 0 to false)]
lifestore_products = [id_product, n ame, price, category, stock]
"""

from lifestore_file import lifestore_products, lifestore_sales, lifestore_searches


"""
------------------LOGIN------------------------------
Usuario:  PeterPanda
Contraseña: DatDarEm&22
"""

#Mensaje de entrada y credenciales
Bienvenida = 'SISTEMA DE GESTIÓN DE VENTAS\n¡Que gusto tenerte de nuevo aquí!\nPor favor ingresa tu usuario y contraseña'
print (Bienvenida)
#Se permitirán 3 intentos de acceso antes de que el programa termine si las credenciales son incorrectas
UsuarioAccedio = False
intentos = 0

while not UsuarioAccedio:
#Credenciales
  usuario = input ("Usuario:")
  contras = input ("Contraseña:")
  intentos += 1
#Verificar que lascredenciales coincidan
  if usuario == "PeterPanda" and contras == "DatDarEm&22":
    UsuarioAccedio = True
    print ("\n-------Bienvenide a los datos de ventas-------\n")
#Si las credenciales no coinciden va a específicar cual no es correcta, aumentando el número de veces que el usuario se equivoque 
  else:
    print(f"Tienes {3 - intentos} intentos restantes")
    if usuario =="PeterPanda":
      print ("Contraseña incorrecta")
    else:
      print ("Usuario no registrado")
#Se termina el programa después del intento érroneo 3
    if intentos == 3:
      print("Límite de intentos alcanzados")
      exit()


"""
---------PRODUCTOS MÁS VENDIDOS Y PRODUCTOS REZAGADOS-----------
"""
#----------------------VENTAS-----------------------------------
#¿Cuáles son los 5 productos con mayores ventas? y ¿Cuáles son los 5 con menores ventas?
#Para esta parte vamos a trabajar con solo listas

#Se  obtiene la venta de cada producto con el total de id´s registrados en lifestore_sales
veces_vendido=[venta[1] for venta in lifestore_sales]
#Creamos una lista principal que contendrá la venta de cada producto junto a información de qué es
ventas_por_producto=[]

#Este for toma elementos de la lista de productos para asignarle la información a una nueva lista provisional que se va a guardar en la lista prncipal para que puedan ser elementos combinados y no listas individuales, los elementos son:
for venta in lifestore_products:
  vent_provi=[]
  ventas_por_producto.append(vent_provi)
  for k in range(1):
    vent_provi.append(venta[0])#ID
    vent_provi.append(venta[1])#nombre
#count es una función aplicable a listas para contar todas las veces que un elemento se repite de una lista(si no existe le asigna el 0), entre paréntesis se pone el argumento con el que va a contar , en este caso será a partir de los id´s
    vent_provi.append(veces_vendido.count(venta[0]))#repeticiones
    vent_provi.append(venta[3])#categoría

#Para ordenar la lista con base en el número de ventas por producto(elemento 2 de ventas_por_producto) se utiliza sorted(), con elementos que nos permitan ordenarlo de mayor a menor (reverse) o el default que los ordena de menor a mayor
vent_pro_ord = sorted(ventas_por_producto, key=lambda s: s[2], reverse=True)

#Imprimimos en pantalla los 5 productos con mayores ventas
print(chr(27)+"[1;36m"+'Los 5 productos con mayores ventas son:\t'+'\033[0;m')
for k in [0,1,2,3,4]:
  print(f"\nDe {vent_pro_ord[k][3]}\n\tEl producto {vent_pro_ord[k][1]}\n\tSe vendió {vent_pro_ord[k][2]} veces\n\tID: {vent_pro_ord[k][0]}")

#Imprimimos en pantalla los 5 productos con menores ventas, usamos vent_pro_ord, y contamos con índices negativos
print(chr(27)+"[1;31m" + '\n\nLos 5 productos con menores ventas son:\t'+'\033[0;m')
for k in [-5,-4,-3,-2,-1]:
  print(f"\nDe {vent_pro_ord[k][3]}\n\tEl producto {vent_pro_ord[k][1]}\n\tSe vendió {vent_pro_ord[k][2]} veces\n\tID: {vent_pro_ord[k][0]}")



#----------------------BÚSQUEDAS-------------------------------#
#¿Cuáles son los 10 productos con mayores búsquedas? y ¿Cuáles son los 10 con menores búsquedas?
#Generamos un código similar al de ventas, pero como base se toma lifestore_sales en conjunto con lifestore_products

#búsquedas de id´s de lifestore_searches
veces_buscado=[busqueda[1] for busqueda in lifestore_searches]
#Lista principal de búsquedas
busquedas_por_producto=[]
#Se genera la adición de los elementos a la lista de búsquedas
for busqueda in lifestore_products:
  busq_provi=[]
  busquedas_por_producto.append(busq_provi)
  for z in range(1):
    busq_provi.append(busqueda[0])#ID
    busq_provi.append(busqueda[1])#nombre
    busq_provi.append(veces_buscado.count(busqueda[0]))#cantbusqs
    busq_provi.append(busqueda[3])#categoria

#Ordenamos la lista con base en las búsquedas y de mayor a menor
busq_pro_ord = sorted(busquedas_por_producto, key=lambda s: s[2], reverse=True)

#Imprimimos en pantalla los 10 productos con mayores busqueda
print(chr(27)+"[1;36m"+'Los 10 productos con mayores búsquedas son:\t'+'\033[0;m')
for k in [0,1,2,3,4,5,6,7,8,9]:
  print(f"\nDe {busq_pro_ord[k][3]}\n\tEl producto {busq_pro_ord[k][1]}\n\tSe buscó {busq_pro_ord[k][2]} veces\n\tID: {busq_pro_ord[k][0]}")

#Imprimimos en pantalla los 5 productos con menores busquedas, usamos busq_pro_ord, y contamos con índices negativos
print(chr(27)+"[1;31m" + '\n\nLos 10 productos con menores búsquedas son:\t'+'\033[0;m')
for k in [-10,-9,-8,-7,-6,-5,-4,-3,-2,-1]:
  print(f"\nDe {busq_pro_ord[k][3]}\n\tEl producto {busq_pro_ord[k][1]}\n\tSe buscó {busq_pro_ord[k][2]} veces\n\tID: {busq_pro_ord[k][0]}")


"""
-------------PRODUCTOS POR RESEÑA EN EL SERVICIO-----------------
"""

#¿Cuáles son los 5 productos con mejores reseñas? y ¿Cuáles son los 5 con las peores?

#En esta parte se va a trabajar con diccionarios

#Se obtienen las reseñas de la lista lifestore_sales y se guardan en un diccionario para poder operar sobre ellas
prods_reviews = {}
for sale in lifestore_sales:
    prod_id = sale[1]
    review = sale[2]
    if prod_id not in prods_reviews.keys():
        prods_reviews[prod_id] = []
    prods_reviews[prod_id].append(review)

#Creamos un diccionario para guardar las reseñas promedio por id
res_promxid = {}

#Se opera sobre el diccionario obtenido de lifestore_sales para obtener el promedio de las reseñas
for id, resenas in prods_reviews.items():
  res_prom= sum(resenas)/len(resenas)
  res_prom=int(res_prom*100)/100
  res_promxid[id]=[res_prom, len(resenas)]


# Se genera una lista a partir del diccionario para poder ordenar y seleccionar elementos
lista_prom_res = []
#A esa lista se le asigna el id, la reseña promedio y el número de reseñas para poder generar la impresión en consola
for id, listprom in res_promxid.items():
    resena_prom = listprom[0]
    repet = listprom[1]
    sub = [id, resena_prom, repet]
    lista_prom_res.append(sub)

#Se ordena de mayor a menor a partir del elemento 'reseña promedio'
lista_prom_res = sorted(lista_prom_res, key=lambda list:list[1], reverse=True)


#Se genera la impresión de los 5 PRODUCTOS CON MEJOR RESEÑA
print(chr(27)+"[1;34m" + '\n\nLos 5 productos con reseñas más altas son:\t'+'\033[0;m')

for elemento in lista_prom_res[:5]:
  #Así se declaran 3 variables que ya están en una lista en una sola línea
    id, resena_prom, numrese = elemento
   #Así se manda llamar la variable desde lifestore_products 
    indice_lsp = id - 1
    producto = lifestore_products[indice_lsp]
    nombre = producto[1]
  #Forma de darle formato a un texto que está incluido en la lista, split separa en palabras y join une por x elemento que se le asigne, es este caso son espacios
    nombre = nombre.split(' ')
    nombre = ' '.join(nombre[:4])
    print(f'El producto "{nombre}":\n\tTuvo una reseña promedio de: {resena_prom}\n\tCon un total de: {numrese} productos vendidos\n\tID: {id}')
    print("\n")

#Se genera la impresión de los 5 PRODUCTOS CON PEOR RESEÑA
print(chr(27)+"[1;31m" + '\n\nLos 5 productos con reseñas más bajas son:\t'+'\033[0;m')

for elemento in lista_prom_res[-5:]:
  #Así se declaran 3 variables que ya están en una lista en una sola línea
    id, resena_prom, numrese = elemento
   #Así se manda llamar la variable desde lifestore_products 
    indice_lsp = id - 1
    producto = lifestore_products[indice_lsp]
    nombre = producto[1]
  #Forma de darle formato a un texto que está incluido en la lista, split separa en palabras y join une por x elemento que se le asigne, es este caso son espacios
    nombre = nombre.split(' ')
    nombre = ' '.join(nombre[:4])
    print(f'El producto "{nombre}":\n\tTuvo una reseña promedio de: {resena_prom}\n\tCon un total de: {numrese} productos vendidos\n\tID: {id}')
    print("\n")


"""
-------------INGRESOS Y VENTAS DE PRODUCTOS-----------------
"""
#En esta parte del código se va a trabajar con los ingresos económicos y el total de ventas, se tomarán en cuenta dos rangos: mensual y anual. Se requiere tomar en cuenta los datos de ventas concluidas satisfactoriamente, es decir, omitir devoluciones

#¿Cuál fue el total de ingresos y ventas por mes?###########
#Se toman los datos de lifestore_sales, el [0] marca el id, [3] está asociado a la fecha para poder clasificar. [4] omite las devoluciones.

#Se crea una lista con los puntos anteriores y columna [4] igual a 0 devoluciones como condicionante
fecha_id = [ [venta[0], venta[3]] for venta in lifestore_sales if venta[4] == 0 ]
#Se crea el diccionario que contendrá los ids de ventas por mes
ventas_meses = {}

#Ya que fecha_id solo tiene un par de datos:
for par in fecha_id:
    id_venta= par[0]
    #Se especifíca la variable a trabajar de la columa[1], especificando el tipo de separador
    _, mes,_ = par[1].split('/')
    #Se agregan los meses como llave al diccionario
    if mes not in ventas_meses.keys():
        ventas_meses[mes] = []
    #Estos contendrán los elementos de las ventas correspondientes
    ventas_meses[mes].append(id_venta)


#Para darle formato a las ventas por mes es necesario operar sobre el diccionario anteior y agregar los datos de lifestore_products
#Se crea un nuevo diccionario que contenga el número de ventas, junto al total de ganancias por mes
ventas_mensuales = {}
#Se pone el print general del título de los datos
print(chr(27)+"[1;32m" + '\n\nVENTAS E INGRESOS MENSUALES\t'+'\033[0;m')

for mes, id_venta in ventas_meses.items():
    ventas_xmes = id_venta
    venta_total = 0
    #Se agregan los datos de las ventas por mes
    for Id_venta in ventas_xmes:
        ind = Id_venta - 1
        info_venta = lifestore_sales[ind]
        id = info_venta[1]
        info_prod = lifestore_products[id-1]
        #El precio lo contiene lifestore_products y se hace una suma
        precio = info_prod[2]
        venta_total += precio
    #Se confirman los valores contenidos en ventas_mensuales, cuyas llaves son los meses
    ventas_mensuales[mes] = [venta_total, len(ventas_xmes)]

#Como queremos conocer también cuáles son los meses con más ventas en el año,del diccionario se crea una lista para poder imprimir en orden 
mensuales_ventas = []
for mes, datos in ventas_mensuales.items():
    ingresos, ventas = datos
    sub = [mes, ingresos, ventas]
    mensuales_ventas.append(sub)

#Se ordena la lista por ventas
ord_ventas = sorted(mensuales_ventas, key=lambda x:x[2], reverse=True)
#Este print ordena las ventas mensuales con base en el mayor número de ventas con lo pide el punto 3 del reporte
for k in [0,1,2,3,4,5,6,7]:
  print(f"\nEn {ord_ventas[k][0]}\n\tSe vendió un total de: $ {ord_ventas[k][1]}\n\tCon {ord_ventas[k][2]} productos vendidos\n")
    


#Ventas promedio mensuales total de ventas anuales#######################
#Se crea una lista de solamente la cantidad de ventas mensuales
ventas_prom_men = []
for mes, datos in ventas_mensuales.items():
    num_ventas = datos[1]
    ventas_prom_men.append(num_ventas)
#Se requiere el promedio de ventas mensuales, se opera con la suma y el tamaño de ventas_prom_men
total_vent_anual=sum(ventas_prom_men)
prom_vent_anual=round(total_vent_anual/(len(ventas_prom_men)))
#Se imprime el total de ventas que se tuvieron en el año
print(chr(27)+"[1;33m" + '\n\nLa cantidad total de productos vendidos en el año fueron:\n\t'+'\033[0;m',total_vent_anual,'unidades')
#Se imprime el promedio de ventas mensuales 
print(chr(27)+"[1;33m" + '\n\nLa cantidad promedio de productos vendidos por mes fueron:\n\t'+'\033[0;m',prom_vent_anual,'unidades')

#Ingresos promedio mensuales, total de ingresos anuales##################
#Se crea una lista de solamente la cantidad de ingresos mensuales
ingresos_prom_men = []
for mes, datos in ventas_mensuales.items():
    ingresos = datos[0]
    ingresos_prom_men.append(ingresos)
#Se requiere el promedio de ingresos mensuales, se opera con la suma y el tamaño de ingresos_prom_men
total_ing_anual=sum(ingresos_prom_men)
prom_ing_anual=total_ing_anual/(len(ingresos_prom_men))
#Se imprime el total de ingresos que se tuvieron en el año
print(chr(27)+"[1;35m" + '\n\nLa cantidad total de ingresos en el año fue de:\n\t'+'\033[0;m','$',total_ing_anual)
#Se imprime el promedio de ventas mensuales 
print(chr(27)+"[1;35m" + '\n\nEl ingreso mensual promedio en el año fue de:\n\t'+'\033[0;m','$',prom_ing_anual)
